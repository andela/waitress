/* eslint strict:0, func-names:0, no-use-before-define:0,
no-param-reassign:0, no-var:0 */
'use strict';

angular.module('waitress')
.controller('MainController', mainCtrl);

mainCtrl.$inject = ['$scope', '$http', '$ionicPopup', '$log', '$httpParamSerializerJQLike', '$state'];

function mainCtrl($scope, $http, $ionicPopup, $log, $httpParamSerializerJQLike, $state) {
  $log.debug('firing events');
  $http.get('http://waitressandela.herokuapp.com/meal-sessions/').then(function (result) {
    $log.debug(result.data.before_midday);
    $scope.beforeMidday = result.data.before_midday;
  });


  var _nextAction = undefined;

  $scope.passphraseDialogVisible = false;

  // $scope.start = function() {
  //   console.log('ydhfd');
  //   MealSession.start($scope.beforeMidday, $scope.passphrase, function(res) {
  //     if (res.status == "Invalid passphrase") {
  //       toastr.error('Invalid Passphrase!');
  //     } else {
  //       $localForage.setItem('waitressSession', {
  //         date: moment().format("YYYY-MM-DD"),
  //         before: $scope.beforeMidday
  //       }).then(function() {
  //         toastr.success('Session started!');
  //         $scope.clearDialog();
  //         window.location = '/start';
  //       });
  //     }
  //   });
  // };
   $scope.show = function(){
    $scope.data = {};
    $ionicPopup.show({
    template: '<input type="password" ng-model="data.password">',
    title: 'Enter Passphrase here',
    cssClass: 'passphraseDialog',
    scope: $scope,
    buttons: [
      {
        text: '<b>Submit</b>',
        type: 'button-positive',
        onTap: function(e) {

          $log.debug($scope.data.password);
          if (!$scope.data.password) {
            $log.debug("not entered")
             e.preventDefault();
          } else {
            var data = {'before_midday':$scope.beforeMidday, 'passphrase':$scope.data.password};
            $log.debug(data);
            $http({
              method: 'POST',
              url:'http://waitressandela.herokuapp.com/meal-sessions/start/',
              data: $httpParamSerializerJQLike(data),
              headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
              }
            }).then(function(result){
                  if(result.data.status){

                    $state.go('tap');
                  }

                }).catch(function(resp){
                  $log.debug(resp);
                })
          }
        }
      },
      { text: 'Cancel' }
    ]
  }).then(function(result){

  });
};

  $scope.secureAction = function(action) {
    _nextAction = action;
    $scope.show()
  };

  $scope.processAction = function() {
    switch (_nextAction) {
      case 'start':
        $scope.start()
        break;
      case 'stop':
        $scope.stop()
        break;
      default:
        break;
    }
  }

  $scope.clearDialog = function() {
    $scope.passphrase = "";
    $scope.passphraseDialogVisible = false;
  }

};
