angular.module('waitress')
    .controller('TapController', tapCtrl);
tapCtrl.$inject = ['$scope'];

function tapCtrl($scope){
    $scope.test = "blank page"

}